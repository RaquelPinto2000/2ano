
public enum TipoCliente {
	Balcao,
	Online
}
