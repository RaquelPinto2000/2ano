package exame;

public enum TipoCama {
	manual, eletrica;
}
