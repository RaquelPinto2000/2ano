package exame;

public enum Tipo {
	Madeira, Plastico, Metal, Sintetico;
}
