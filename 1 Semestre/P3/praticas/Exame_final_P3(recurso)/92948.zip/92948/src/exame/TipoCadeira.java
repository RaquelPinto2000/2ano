package exame;

public enum TipoCadeira {
	Atendimento, Espera, Escritorio;
}
