package exame;

public interface Transporte {

	public TipoTransporte getTipo();
}
