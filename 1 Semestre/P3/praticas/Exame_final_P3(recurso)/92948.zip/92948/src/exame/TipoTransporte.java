package exame;
// ver se tem mais
public enum TipoTransporte {
	MobilidadeReduzida,Urgente;
}
