
Ficheiros TXT de Sedgewick & Wayne

ATENÇÃO:
Quando existem, os pesos das arestas são números reais.
CONVERTER PARA INTEIROS, para podemos usar o nosso TAD!!

FORMATO:
0 / 1 É grafo orientado ?
0 / 1 Há pesos associados às arestas ?
Número de vértices
Número de arestas
vértice inicial vértice final (peso, se existir)
....
....